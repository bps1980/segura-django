import { VNode } from 'preact';
export declare function decode(content: string): string;
export declare function html(content: string, parentElement?: string): VNode;
