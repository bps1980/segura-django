export declare const throttle: (fn: (...args: any[]) => void, wait?: number) => (...args: any[]) => void;
