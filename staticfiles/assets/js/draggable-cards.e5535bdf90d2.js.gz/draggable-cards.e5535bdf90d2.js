(function () {
    "use strict";

    dragula([document.querySelector('#draggable-left'), document.querySelector('#draggable-right')]);
    
})();