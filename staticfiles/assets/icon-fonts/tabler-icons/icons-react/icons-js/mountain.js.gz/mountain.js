import * as React from "react";

function IconMountain({
  size = 24,
  color = "currentColor",
  stroke = 2,
  ...props
}) {
  return <svg xmlns="http://www.w3.org/2000/svg" className="icon icon-tabler icon-tabler-mountain" width={size} height={size} viewBox="0 0 24 24" strokeWidth={stroke} stroke={color} fill="none" strokeLinecap="round" strokeLinejoin="round" {...props}><desc>{"Download more icon variants from https://tabler-icons.io/i/mountain"}</desc><path stroke="none" d="M0 0h24v24H0z" fill="none" /><path d="M3 20h18l-6.921 -14.612a2.3 2.3 0 0 0 -4.158 0l-6.921 14.612z" /><path d="M7.5 11l2 2.5l2.5 -2.5l2 3l2.5 -2" /></svg>;
}

export default IconMountain;