import * as React from "react";

function IconIdBadge2({
  size = 24,
  color = "currentColor",
  stroke = 2,
  ...props
}) {
  return <svg xmlns="http://www.w3.org/2000/svg" className="icon icon-tabler icon-tabler-id-badge-2" width={size} height={size} viewBox="0 0 24 24" strokeWidth={stroke} stroke={color} fill="none" strokeLinecap="round" strokeLinejoin="round" {...props}><desc>{"Download more icon variants from https://tabler-icons.io/i/id-badge-2"}</desc><path stroke="none" d="M0 0h24v24H0z" fill="none" /><path d="M7 12h3v4h-3z" /><path d="M10 6h-6a1 1 0 0 0 -1 1v12a1 1 0 0 0 1 1h16a1 1 0 0 0 1 -1v-12a1 1 0 0 0 -1 -1h-6" /><rect x={10} y={3} width={4} height={5} rx={1} /><path d="M14 16h2" /><path d="M14 12h4" /></svg>;
}

export default IconIdBadge2;